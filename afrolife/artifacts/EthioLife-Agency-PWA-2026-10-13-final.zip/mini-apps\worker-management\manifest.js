export default Object.freeze({
  id: 'worker-management',
  name: 'Worker Management',
  logo: '/mini-apps/worker-management/logo.svg',
  description: 'Register workers, manage profiles, and review workforce documents.',
  panels: ['workers'],
  api: ['/workers', '/documents'],
});
